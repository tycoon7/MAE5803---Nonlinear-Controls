## An Example for Sliding Mode Control

The system is a second order system, consisting of a mass and a damper. 

The SMC is equipped with chattering reduction mechanism by implementing boundary around the sliding surface.

- Please run: run_simu.m
- Check: smc_mass_1d.slx
